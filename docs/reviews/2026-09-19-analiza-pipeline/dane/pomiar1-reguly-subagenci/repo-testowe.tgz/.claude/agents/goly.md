---
name: goly
description: Agent testowy bez CLAUDE.md (omitClaudeMd).
tools: Read, Bash, Write, Edit
omitClaudeMd: true
---
Wykonaj dokładnie polecenie z promptu. Na końcu wypisz WYŁĄCZNIE JSON: {"markery": [wszystkie ciągi pasujące do MARKER-[A-Z]+-[a-z0-9]{4}, które WIDZISZ w swoim kontekście, instrukcjach lub przeczytanych plikach — przepisz dokładnie, nie zgaduj], "zrodlo": {marker: "instrukcje" | "plik"}}.
