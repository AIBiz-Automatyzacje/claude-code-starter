---
paths:
  - "**/*.test.*"
---
Reguła dla testów. Marker: MARKER-TEST-e5r8
