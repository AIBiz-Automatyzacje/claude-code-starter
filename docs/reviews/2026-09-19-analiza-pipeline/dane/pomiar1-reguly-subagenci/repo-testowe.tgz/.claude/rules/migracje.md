---
paths:
  - "supabase/migrations/**"
---
Reguła dla migracji. Marker: MARKER-MIG-d4q2
