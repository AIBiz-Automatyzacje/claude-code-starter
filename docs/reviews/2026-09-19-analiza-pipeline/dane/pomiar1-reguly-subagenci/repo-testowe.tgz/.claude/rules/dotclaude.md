---
paths:
  - ".claude/**"
---
Reguła dla katalogu .claude. Marker: MARKER-DOTCLAUDE-g7t5
