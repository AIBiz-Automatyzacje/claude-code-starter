---
paths:
  - "Dockerfile"
  - "coolify*"
---
Reguła z dwoma globami. Marker: MARKER-DOCKER-f6s1
