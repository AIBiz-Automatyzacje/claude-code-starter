---
paths:
  - "src/**"
---
Reguła nakładająca się z tsx (src/**). Marker: MARKER-SRCALL-h8u3
