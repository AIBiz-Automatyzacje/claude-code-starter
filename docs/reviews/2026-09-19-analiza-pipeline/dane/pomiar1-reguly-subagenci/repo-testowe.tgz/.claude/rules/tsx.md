---
paths:
  - "src/**/*.tsx"
---
Reguła dla komponentów. Marker: MARKER-TSX-c3p7
