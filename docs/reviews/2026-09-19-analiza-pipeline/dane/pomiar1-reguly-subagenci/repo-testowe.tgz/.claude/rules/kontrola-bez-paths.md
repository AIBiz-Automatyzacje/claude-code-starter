Reguła kontrolna bez pola paths. Marker: MARKER-BEZPATHS-b2m4
